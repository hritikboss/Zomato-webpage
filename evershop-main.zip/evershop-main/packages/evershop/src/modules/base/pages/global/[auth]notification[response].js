// eslint-disable-next-line no-unused-vars
module.exports = (request, response) => {
  // console.log(response.context)
  // console.log(request.session)
  // response.context.notifications = [...request.session.notifications || []];
  // request.session.notifications = [];
};
